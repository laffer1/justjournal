using System;
using System.Web;
using System.IO;
using System.Collections;
using System.Collections.Specialized;
using System.Windows.Forms;
using System.Net;
using Microsoft.Win32;
using System.Text.RegularExpressions;
using System.Text;
using System.Security.Cryptography;

namespace JustJournal
{
	/// <summary>
	/// Summary description for JustJournal.
	/// </summary>
	public class JustJournal
	{
        private static string server = "www.justjournal.com";

		public const string version = "JustJournal/1.0.2 Win";

		public static bool loggedIn = false;
		public static string userName;
		public static string password;
		public static string debug;
		public static ArrayList moods = new ArrayList(125);

        public static bool useSSL = true;

		public static bool Login()
		{
			string uriString;
			WebClient client = new WebClient();	
			if (useSSL)
                uriString = "https://";
			else
			    uriString = "http://";
			 
			uriString += "www.justjournal.com/loginAccount";
			
			// Create a new NameValueCollection instance to hold some custom parameters to be posted to the URL.
			NameValueCollection myNameValueCollection = new NameValueCollection();

			// Add a user agent header in case the 
			// requested URI contains a query.
			client.Headers.Add("User-Agent", version);

			myNameValueCollection.Add("username", userName);            
			myNameValueCollection.Add("password", password);
			myNameValueCollection.Add("password_hash", "");

			byte[] responseArray = client.UploadValues(uriString,"POST",myNameValueCollection);
			//Encoding.ASCII.GetString(responseArray)

			string resp = Encoding.ASCII.GetString(responseArray);
			debug = resp.ToString();
			if ( resp.Length > 0 && resp.IndexOf("JJ.LOGIN.OK") == -1 ) 
				return false;
			else
				return true;
		}

		public static void RetrieveMoods()
		{
            string uriString;
			//System.Collections.SortedList moods = new SortedList(125);
			WebClient client = new WebClient();
			uriString = "http://www.justjournal.com/moodlist.h";

		    client.Headers.Add("User-Agent", version);
			byte[] responseArray = client.DownloadData(uriString);
			string resp = Encoding.UTF8.GetString(responseArray);
			System.Xml.XmlDocument xdoc = new System.Xml.XmlDocument();
			xdoc.LoadXml(resp);

			System.Xml.XmlNodeList nl = xdoc.SelectNodes("model/moods/*");

			moods.Clear();  // clear the list
			for (int n = 0; n < nl.Count; n++)
			{
				moods.Add(new Mood(nl.Item(n).ChildNodes.Item(0).InnerText,nl.Item(n).ChildNodes.Item(2).InnerText));
			}
		}

		public JustJournal()
		{
			//
			// TODO: Add constructor logic here
			//
		}

	}
}
