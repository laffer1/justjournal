var localizedStrings = new Object;

localizedStrings["Done"] = "Done";
localizedStrings['subject'] = 'Subject';
localizedStrings['Button'] = 'Post Blog';
