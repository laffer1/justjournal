
package com.justjournal.db;

/**
 * Created by IntelliJ IDEA.
 * User: laffer1
 * Date: Jan 21, 2004
 * Time: 1:09:29 PM
 * To change this template use Options | File Templates.
 */
public class UserContactDao
{
}
