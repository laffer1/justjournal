
package com.justjournal.ctl;

/**
 * Created by IntelliJ IDEA.
 * User: laffer1
 * Date: Jan 3, 2004
 * Time: 6:48:18 PM
 * To change this template use Options | File Templates.
 */
public class Default extends ControllerAuth
{
    public String perform() throws Exception
    {
        return SUCCESS;
    }
}
