
package com.justjournal.db;

/**
 * Created by IntelliJ IDEA.
 * User: laffer1
 * Date: Jan 9, 2004
 * Time: 1:55:59 PM
 * To change this template use Options | File Templates.
 */
public class SecurityTo
{
    private int id;
    private String name;

    public int getId()
    {
        return this.id;
    }

    public void setId( int id)
    {
        this.id = id;
    }

    public String getName()
    {
        return this.name;
    }

    public void setName( String name )
    {
        this.name = name;
    }
}
