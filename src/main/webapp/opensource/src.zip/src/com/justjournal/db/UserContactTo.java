
package com.justjournal.db;

/**
 * Created by IntelliJ IDEA.
 * User: laffer1
 * Date: Jan 21, 2004
 * Time: 12:59:36 PM
 */
public class UserContactTo
{
    private String email;
    private String icq;
    private String aim;
    private String yahoo;
    private String msn;
    private String phone;
    private String hpTitle;
    private String hpUri;


    public String getEmail()
    {
        return this.email;
    }

    public void setEmail( final String email )
    {
        this.email = email;
    }

    public String getIcq()
    {
        return this.icq;
    }

    public void setIcq( final String icq )
    {
        this.icq = icq;
    }

    public String getAim()
    {
        return this.aim;
    }

    public void setAim( final String aim )
    {
        this.aim = aim;
    }

    public String getYahoo()
    {
        return this.yahoo;
    }

    public void setYahoo( final String yahoo )
    {
        this.yahoo = yahoo;
    }

    public String getMsn()
    {
        return this.msn;
    }

    public void setMsn( final String msn )
    {
        this.msn = msn;
    }

    public String getPhone()
    {
        return this.phone;
    }

    public void setPhone( final String phone )
    {
        this.phone = phone;
    }

    public String getHpTitle()
    {
        return this.hpTitle;
    }

    public void setHpTitle( final String hpTitle )
    {
        this.hpTitle = hpTitle;
    }

    public String getHpUri()
    {
        return this.hpUri;
    }

    public void setHpUri( final String hpUri )
    {
        this.hpUri = hpUri;
    }
}
